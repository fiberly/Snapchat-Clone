//
//  ViewController2.swift
//  ParseStarterProject-Swift
//
//  Created by Daniel Barton on 2/7/21.
//  Copyright © 2021 Parse. All rights reserved.
//

import UIKit
import Parse

class ViewController2: UIViewController {

    @IBAction func logOutAction(_ sender: AnyObject) {
   
        PFUser.logOut();
        
        performSegue(withIdentifier: "LogOutIdentifier", sender: self);
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
