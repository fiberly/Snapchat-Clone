/**
* Copyright (c) 2015-present, Parse, LLC.
* All rights reserved.
*
* This source code is licensed under the BSD-style license found in the
* LICENSE file in the root directory of this source tree. An additional grant
* of patent rights can be found in the PATENTS file in the same directory.
*/

import UIKit
import Parse

class ViewController: UIViewController {
    
    // could maybe just do a username app to have it as a username only kind of app
    
    var signUpCheck = true;
    
    var activitySpinner = UIActivityIndicatorView();
    
    @IBOutlet weak var usernameTFOutlet: UITextField!
    
    @IBOutlet weak var passwordTFOutlet: UITextField!
   
    @IBOutlet weak var signUpButtonOutlet: UIButton!
    
    @IBOutlet weak var loginButtonOutlet: UIButton!
    
    @IBOutlet weak var loginAndOrSignUpLabel: UILabel!
    
    @IBOutlet weak var errorMessageLabel: UILabel!
    
    @IBAction func signUpAction(_ sender: UIButton) {
        
        self.errorMessageLabel.isHidden = true;
        
        if usernameTFOutlet.text == "" || passwordTFOutlet.text == "" {
            
           // alertPopUp(title: "Username and or password error?", message: "Try entering the credentials again?");
            
        } else {
            
            activitySpinner = UIActivityIndicatorView(frame: CGRect(x: 50, y: 0, width: 50, height: 50));
            
            activitySpinner.center = self.view.center;
            
            activitySpinner.hidesWhenStopped = true;
            
            activitySpinner.style = UIActivityIndicatorView.Style.gray;
            
            view.addSubview(activitySpinner);
            
            self.activitySpinner.startAnimating();
            
            UIApplication.shared.beginIgnoringInteractionEvents();
            
            if signUpCheck {
              
                let newUser = PFUser();
              
                newUser.username = usernameTFOutlet.text;
              
                newUser.password = passwordTFOutlet.text;
              
                newUser.signUpInBackground(block: { (worked, errors) in
                
                    self.activitySpinner.stopAnimating();
                  
                    UIApplication.shared.endIgnoringInteractionEvents();
                    
                    if errors != nil {
                      
                        var showErrorMessage = "Please try signing up again?";
                       
                        let errors = errors as NSError?;
                       
                        if let errorsToAString = errors?.userInfo["error"] as? String {
                        
                            showErrorMessage = errorsToAString;
                            
                        }
                    
                    //    self.alertPopUp(title: "error from the server side :/", message: showErrorMessage);
                        
                        self.errorMessageLabel.text! = showErrorMessage;
                        
                        self.errorMessageLabel.isHidden = false;
                        
                    } else {
                     
                        print("user signed up successfully!");
                     
                        self.performSegue(withIdentifier: "LogInIdentifier", sender: self);
                        
                        self.errorMessageLabel.isHidden = true;
                        
                    }
                })
                
            } else {
                
                PFUser.logInWithUsername(inBackground: usernameTFOutlet.text!, password: passwordTFOutlet.text!, block: { (login, didNotWork) in
                   
                    self.activitySpinner.stopAnimating();
                   
                    UIApplication.shared.endIgnoringInteractionEvents();
                    
                    if didNotWork != nil {
                      
                        var showErrorMessage2 = "Please try logging in again?";
                       
                        let didNotWork = didNotWork! as NSError;
                       
                        if let didNotWorkToString = didNotWork.userInfo["error"] as? String {
                         
                            showErrorMessage2 = didNotWorkToString
                        
                        }
                       
                      //  self.alertPopUp(title: "Trouble logging in?", message: showErrorMessage2);
                        
                        self.errorMessageLabel.text! = showErrorMessage2;
                        
                        self.errorMessageLabel.isHidden = false;
                        
                    } else {
                        
                        print("You are now logged in?");
                        
                        
                        self.performSegue(withIdentifier: "LogInIdentifier", sender: self);
                        
                        self.errorMessageLabel.isHidden = true;
                    
                    }
                })
            }
        }
        
        print(signUpCheck);
        
    }
    
    @IBAction func logInAction(_ sender: UIButton) {
    
        if signUpCheck {
            
            signUpButtonOutlet.setTitle("Log In", for: []);
            
            loginButtonOutlet.setTitle("Sign Up", for: []);
            
            loginAndOrSignUpLabel.text = "Do you not have an account? ";
            
            signUpCheck = false;
            
        } else {
            
            signUpButtonOutlet.setTitle("Sign Up", for: []);
            
            loginButtonOutlet.setTitle("Log In", for: []);
            
            loginAndOrSignUpLabel.text = "Do you already have an account?";
            
            signUpCheck = true;
        
        }
    }
    
    func alertPopUp(title: String, message: String) {
        
        let loginAndOrSignUpAlert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert);
        
        loginAndOrSignUpAlert.addAction(UIAlertAction(title: "Okay", style: .default, handler: { (alertAction) in
            
            self.dismiss(animated: true, completion: nil);
            
        }));
        
        self.present(loginAndOrSignUpAlert, animated: true, completion: nil);
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        if PFUser.current() != nil {
            
            performSegue(withIdentifier: "LogInIdentifier", sender: nil);
            
        }
        
        self.navigationController?.navigationBar.isHidden = true;
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
