//
//  TableViewController.swift
//  ParseStarterProject-Swift
//
//  Created by Daniel Barton on 6/7/21.
//  Copyright © 2021 Parse. All rights reserved.
//

import UIKit
import Parse

class TableViewController: UITableViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    var usernames = [String]();
         
    var messageRecipients = "";
    
    // variables defined inside a class need to have a value, they can not be nil
    
    var timer = Timer();
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "LogOutIdentifier" {
            
            PFUser.logOut();
            
            self.navigationController?.navigationBar.isHidden = true;
            
        }
    }
    
    @objc func messagesCheckFor() {
        
        print("timer was activated");
        
        let query = PFQuery(className: "Image");
        
        query.whereKey("recipientUsername", equalTo: PFUser.current()?.username! as Any);
        
        do {
            
            let images = try query.findObjects();
            
            if images.count > 0 {
                
                    var usernameOfTheSender = "User was unknown?";
                
                    if let username = images[0]["senderUsername"] as? String {
                        
                        usernameOfTheSender = username;
                        
                    }
                
                    if let pFFile = images[0]["photo"] as? PFFile {
                        
                        pFFile.getDataInBackground(block:  { (data, error) in
                            
                            if let dataOfImage = data {
                                
                                images[0].deleteInBackground();
                                
                                self.timer.invalidate();
                                
                                if let displayedScreenImage = UIImage(data: dataOfImage) {
                                    
                                    let alertController = UIAlertController(title: "You Have Recieved a Message", message: "Message is from " + usernameOfTheSender, preferredStyle: .alert);
                                    
                                    alertController.addAction(UIAlertAction(title: "Okay", style: .default, handler: { (action) in
                                        
                                        let backgroundGreyedView = UIImageView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height));
                                        
                                        backgroundGreyedView.backgroundColor = UIColor.black;
                                        
                                        backgroundGreyedView.alpha = 0.8;
                                        
                                        backgroundGreyedView.tag = 10;
                                        
                                        self.view.addSubview(backgroundGreyedView);
                                        
                                        let imageViewDisplayed = UIImageView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height));
                                        
                                        imageViewDisplayed.image = displayedScreenImage;
                                        
                                        imageViewDisplayed.tag = 10;
                                        
                                        imageViewDisplayed.contentMode = UIView.ContentMode.scaleAspectFit;
                                        
                                        self.view.addSubview(imageViewDisplayed);
                                        
                                        _ = Timer.scheduledTimer(withTimeInterval: 5, repeats: false, block: { (timer) in
                                        
                                            self.timer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(TableViewController.messagesCheckFor), userInfo: nil, repeats: true);
                                            
                                            for subview in self.view.subviews {
                                            
                                                if subview.tag == 10 {
                                                    subview.removeFromSuperview();
                                                    
                                                }
                                            }
                                        })
                                    }))
                                   
                                    self.present(alertController, animated: true, completion: nil);
                                
                                }
                            }
                        })
            }
        
        }
            
    } catch {
        
    print("could not retrieve the image(s)");
        
    }
}
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.navigationController?.navigationBar.isHidden = false;
        
        timer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(TableViewController.messagesCheckFor), userInfo: nil, repeats: true);
        

        
        let query = PFUser.query();
        
        query?.whereKey("username", notEqualTo: (PFUser.current()?.username)!);
        
        // using the do catch, goes with the flow of the code
        // without the do catch, would run in the background
        
        do {
            
        let users =  try query?.findObjects()
            
            if let users = users as? [PFUser] {
                
                for user in users {
                    
                    self.usernames.append(user.username!);
                }
                tableView.reloadData();
            }
        } catch {
    }
}

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
       
        return 1;
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        return usernames.count;
        
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVCell", for: indexPath);

        // Configure the cell...

        cell.textLabel?.text = usernames[indexPath.row];
        
        
        return cell;
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        messageRecipients = usernames[indexPath.row];
        
        let imagePickerController = UIImagePickerController();
        
        imagePickerController.delegate = self;
        
        imagePickerController.sourceType = .photoLibrary;
        
        imagePickerController.allowsEditing = false;
        
        self.present(imagePickerController, animated: true, completion: nil);
        
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            
            print("image was returned");
            
            let imageSentTo = PFObject(className: "Image");
            
            imageSentTo["photo"] = PFFile(name: "photo.png", data: image.jpegData(compressionQuality: 1)!);
            
            imageSentTo["senderUsername"] = PFUser.current()?.username;
            
            imageSentTo["recipientUsername"] = messageRecipients;
            
            imageSentTo.saveInBackground { (saved, notSaved) in
                
                var title = "Sending Failed";
                
                var description = "Please try again another time?";
                
                if saved {
                    
                    title = "Message Successfully Sent!";
                    
                    description = "Your message was sent?";
                    
                }
                
                let alertController = UIAlertController(title: title, message: description, preferredStyle: .alert);
                
                alertController.addAction(UIAlertAction(title: "Okay", style: .default, handler: { (action) in
                    
                    alertController.dismiss(animated: true, completion: nil);
                    
                }))
                
                self.present(alertController, animated: true, completion: nil);
                
            }
        }
        
        self.dismiss(animated: true, completion: nil);
        
    }
    

}
